#include <iostream>
#include <vector>
#include <cstdlib>      // ЛР 31.03 Лоташ Михайло + Божок Родіон
#include <ctime>
#include <algorithm>
using namespace std;
vector<int> armain;
int main()
{
    srand(time(NULL));
int trash = 0;
  for(int i=0; i<rand() % (100 - (-100) + 1); ++i){
      armain.push_back(rand() % 100);
  cout << armain[i] << endl;
  trash++;
  }
  int max = 0;
  for (int i = 0; i <= trash; i++) {
    if (armain[i] > max)
        max = armain[i];
  }
  cout << "\nmax element = " << max << endl;
  sort(armain.begin(), armain.end());
 //  ========================== task2
  cout << "Sorted:" << endl;
  for (int i = 0; i < trash; i++) {
    cout << armain[i] << endl;
  }
  //============================ task3
  float sum = 0;
  for (int i = 0; i < trash; i++) {
    sum += armain[i];
  }

  cout << "\nSum = " << sum << endl;
  cout << "\nMiddle = " << sum / trash << endl;


    return 0;
}
