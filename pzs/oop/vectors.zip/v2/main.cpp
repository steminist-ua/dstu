#include <iostream>
#include <vector>

using namespace std;

class Person
{
private:
    string name;
    int age;
public:
    Person(string _name, int _age) : name(_name), age(_age){}
    string getName(){
        return this->name;
    }
    int getAge(){
        return this->age;
    }
    void Display(){
        cout << "Name: "<< this->name << "Age: "<< this->age << endl;
    }
};

int main()
{
    vector<Person> people;
    people.push_back(Person("Vasia", 50));
    people.push_back(Person("Vasyliy", 100));
    people.push_back(Person("Vaska", 150));

    cout << people.size() << endl;

    for(int i = 0; i < people.size(); i++){
        people[i].Display();
    }

    people[2] = Person("Artem", 20);

    for(int i = 0; i < people.size(); i++){
        people[i].Display();
    }

    return 0;
}
