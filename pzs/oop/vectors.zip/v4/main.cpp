#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector<vector<int>> matrix;

    vector<int> row1 = {1, 2, 3};
    vector<int> row2 = {INT32_MIN, INT32_MAX};
    vector<int> row3 = {15, 16, -1};

    matrix.push_back(row1);
    matrix.push_back(row2);
    matrix.push_back(row3);

    for(const auto& row : matrix){
        for(const auto& col : row){
            cout << col << " ";
        }
        cout << endl;
    }

    return 0;
}
