#include <iostream>
#include <vector>

using namespace std;

struct Point{
    int x;
    int y;
};

int main()
{
    vector<Point> points;

    points.push_back(Point{1, 2});
    points.push_back(Point{5, 6});
    points.push_back(Point{INT32_MIN, INT32_MAX});

    for(const auto& point : points){
        cout << "x: " << point.x << " y: " << point.y << endl;
    }

    return 0;
}
