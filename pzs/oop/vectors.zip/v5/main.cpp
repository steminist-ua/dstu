#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Task{
    string name;
    string date;
    int priority;

    Task(string _name, string _date, int _priority) : name(_name), date(_date), priority(_priority){}
};

int main()
{
    vector<Task> tasks;
    tasks.push_back(Task("Complete project", "30.03.2023", 1));
    tasks.push_back(Task("Study for exam", "20.05.2023", 3));
    tasks.push_back(Task("Go to gym", "28.03.2023", 2));
    tasks.push_back(Task("Buy products", "28.03.2023", 4));

    cout << "Count: " << tasks.size() << endl;

    sort(tasks.begin(), tasks.end(), []
         (const Task& t1, const Task& t2){
            return t1.priority > t2.priority;
    });

    for (const auto& task : tasks){
        cout << task.priority <<": "<< task.name << " (" << task.date << ") " << endl;
    }

    return 0;
}
