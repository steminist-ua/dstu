#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> vec;
    vec.push_back(1);
    vec.push_back(2);
    vec.push_back(3);

    cout << "Vector size: "<< vec.size() << endl;

    vec[1] = 23;
    for(int i = 0; i < vec.size(); i++){
        cout << vec[i] << endl;
    }

    vec.erase(vec.begin() + 1);
    for(int i = 0; i < vec.size(); i++){
        cout << vec[i] << endl;
    }



    cout << "Hello World!" << endl;
    return 0;
}
