#pragma once
class Myclass
{
public:
	Myclass(void);
	~Myclass(void);
	void Displei ();
	void set (int rgs);
private:
int rgs; 

};

