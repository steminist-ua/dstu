// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Myclass.h"


int _tmain(int argc, _TCHAR* argv[])
{Myclass mbnh;
mbnh.Displei();
mbnh.set(4);
mbnh.Displei();
	return 0;
}

