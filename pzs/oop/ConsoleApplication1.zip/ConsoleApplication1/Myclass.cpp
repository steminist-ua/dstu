#include "stdafx.h"
#include "Myclass.h"
#include <iostream>
using namespace std;


Myclass::Myclass(void)
{
	this->rgs=9;
}


Myclass::~Myclass(void)
{
}
void Myclass::Displei(){cout<<this->rgs;}
void Myclass::set(int rgs){this->rgs=rgs;}