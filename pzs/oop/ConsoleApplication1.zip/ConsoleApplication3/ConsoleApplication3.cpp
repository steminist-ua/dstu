// ConsoleApplication3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Cats.h"
#include <string>
#include "Rectamgle.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{

	Cats barsik("Barsik", 1);
	barsik.eat();
	barsik.mow();
	barsik.display();

	Rectamgle square(12, 5, 45);
	square.display();
	square.outId();

	return 0;

}

