#include "stdafx.h"
#include "Shade.h"

Shade::Shade(void)
{
	this->id=0;
	this->high=0;
	this->waith=0;
}
Shade::Shade(int high, int waith, int id)
{
	this->id=id;
	this->high=high;
	this->waith=waith;
}
int Shade:: plosha()
{
	return this->high*this->waith;
}
int Shade::getId()
{
	return this->id;
}

Shade::~Shade(void)
{
}
