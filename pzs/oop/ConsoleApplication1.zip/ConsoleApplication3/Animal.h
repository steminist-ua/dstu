#pragma once
#include <string>
using namespace std;
class Animal
{
protected: 
	string name;
public:
	void eat();
	Animal(string name);
	~Animal(void);
};

