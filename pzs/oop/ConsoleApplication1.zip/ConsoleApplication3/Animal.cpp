#include "stdafx.h"
#include "Animal.h"
#include <iostream>
#include <string>


using namespace std;

Animal::Animal(string name)
{
	this->name=name;
}
void Animal:: eat()
{
	cout<<"Eat."<<endl;
}

Animal::~Animal(void)
{
}
