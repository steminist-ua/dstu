#pragma once
#include "Shade.h"
class Rectamgle:Shade
{

public:
	Rectamgle(int high, int waith, int id);
	void display();
	void outId();

	~Rectamgle(void);
};

