#pragma once
class Shade
{
private: 
  int id;
protected:
	int high;
	int waith;
public:
	Shade(void);
	Shade(int high, int waith, int id);
	int plosha();
	int getId();
	~Shade(void);
};

