#pragma once
#include "Animal.h"
#include <string>

using namespace std;

class Cats :public Animal
{
private:
	int id;
public:
	void display();
	void mow();
	Cats(string name, int id);
	~Cats(void);
};

