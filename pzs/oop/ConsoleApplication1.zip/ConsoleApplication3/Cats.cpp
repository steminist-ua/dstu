#include "stdafx.h"
#include "Cats.h"
#include <iostream>
#include <string>


using namespace std;

Cats::Cats(string name, int id):Animal(name)
{
	this->id=id;
}
void Cats:: mow(){
	cout<<"Meow!"<<endl;
}
void Cats:: display()
{
cout<< this->id << " "<< this->name <<endl;
}
Cats::~Cats(void)
{
}
