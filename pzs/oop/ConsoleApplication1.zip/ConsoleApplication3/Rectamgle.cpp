#include "stdafx.h"
#include "Rectamgle.h"
#include <iostream>

using namespace std;


Rectamgle::Rectamgle(int high, int waith, int id):Shade(high, waith, id)
{

}

void Rectamgle:: display()
{
	cout<<plosha()<<endl;
}
void Rectamgle:: outId()
{
	cout<<getId();
}
Rectamgle::~Rectamgle(void)
{
}
