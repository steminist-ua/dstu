// ConsoleApplication4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Person.h"
#include "Employee.h"


int _tmain(int argc, _TCHAR* argv[])
{
	//Person pp(20 , "Artem");
	//pp.get();
	Employee pt(1 , 2400.32 , 34 , "Max");
	pt.get2();
	pt.get();
	return 0;
}

