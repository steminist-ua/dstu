#include "stdafx.h"
#include "Manager.h"
#include "Employee.h"
#include "Person.h"

Manager::Manager(int id , float salary , int age , string name, string department) : Employee(id, salary,  age, name)
{
	this->department = department;
	this->index = 0;

}


Manager::~Manager(void)
{
}

void Manager::Add(Employee* empployee)
{
	if (index < 5)
	{
		emp[index] = empployee;
		this->index++;
	}
}

void Manager::Display()
{
	cout << endl << this->department << endl;
	for (int i = 0; i < index; i++)
	{
		emp[i]->get2();
	}
}