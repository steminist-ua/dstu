#pragma once
#include "Employee.h"
#include <string>

class Manager : public Employee
{
public:
	Manager(int id , float salary , int age , string name, string department);
	~Manager(void);
	void Add(Employee* empployee);
	void Display();

protected:
	string department;
	Employee* emp[5];
	
private:
	int index;
};

