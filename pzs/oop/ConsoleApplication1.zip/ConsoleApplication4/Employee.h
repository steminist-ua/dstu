#pragma once
#include "Person.h"
class Employee :public Person
{
public:
	Employee(int id , float salary , int age , string name);
	~Employee(void);
	void get2();
protected: 
	int id;
	float salary;

};



