#include "stdafx.h"
#include "Person.h"
#include <iostream>
#include <string>
using namespace std;


Person::Person(int _age , string _name)
{
	this ->name = _name;
	this ->age = _age;

}


Person::~Person(void)
{
}

void Person::get(){
	cout << this-> name;
	cout << this-> age;
}