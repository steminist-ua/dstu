#include "stdafx.h"
#include "Employee.h"
#include <iostream>
#include <string>
using namespace std;


Employee::Employee(int id , float salary , int age , string name):Person(age , name)
{
	this ->id = id;
	this ->salary = salary;
}


Employee::~Employee(void)
{
}

void Employee::get2(){
cout <<this -> id;
cout <<this -> salary;
cout <<this -> name;
cout <<this -> age;
//cout <<this -> number;
}