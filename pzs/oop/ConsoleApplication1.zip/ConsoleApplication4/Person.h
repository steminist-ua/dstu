#pragma once
#include <iostream>
#include <string>
using namespace std;
class Person
{
public:
	Person(int age , string name);
	~Person(void);
	void get();
protected:
	string name;
	int age;
private:
	int number;

};

