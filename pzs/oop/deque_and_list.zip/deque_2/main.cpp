#include <iostream>
#include <deque>

using namespace std;

int main()
{
    int num = 0;
    deque<int> deq;
    int sum = 0;

    while (cin >> num) {
        deq.push_back(num);
        sum+=num;
        cout<<sum<<endl;
    }

    return 0;
}
