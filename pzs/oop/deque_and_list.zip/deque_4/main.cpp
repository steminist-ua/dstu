#include <iostream>
#include <deque>

using namespace std;

bool isPalindrom(string str){

    if(str.length()<3){
        return false;
    }

    deque<char> deq;
    for(int i = 0; i < str.length(); i++){
        deq.push_back(str[i]);
    }


    while(deq.size()>1){
        if(deq.front() != deq.back()){
            return false;
        }
        deq.pop_front();
        deq.pop_back();
    }


    return true;
}

int main()
{
    cout<<isPalindrom("1221")<<endl;
    cout<<isPalindrom("122")<<endl;
    cout<<isPalindrom("1321")<<endl;
    cout<<isPalindrom("deued")<<endl;
    return 0;
}
