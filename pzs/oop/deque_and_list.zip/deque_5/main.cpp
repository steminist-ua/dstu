#include <iostream>
#include <deque>

using namespace std;

class Document{
public:
    int id;
    bool priority;
    bool isPrinted;

    Document(int _id, bool _priority, bool _isPrinted) : id(_id), priority(_priority), isPrinted(_isPrinted){}
};

int main()
{
    deque<Document> deq;
    deq.push_back(Document(1, false, false));
    deq.push_back(Document(2, true, false));
    deq.push_back(Document(3, false, true));
    deq.push_back(Document(4, false, false));
    deq.push_back(Document(5, false, true));

    while(!deq.empty()){
        Document doc = deq.front();
        deq.pop_front();

        cout << "doc id: " << doc.id << " ";

        if(doc.priority){
            cout << "(priority)";
        }

        if(!doc.isPrinted){
            cout << "waiting" << endl;
            doc.isPrinted = true;
            deq.push_back(doc);
        }
        else{
            cout << "done" << endl;
        }
    }

    cout << "Hello World!" << endl;
    return 0;
}
