#include <iostream>
#include <list>

using namespace std;

class Student
{
public:
    string name;
    int age;

    Student(string _name, int _age) : name(_name), age(_age) {}
};

int main()
{
    list<Student> list;
    list.push_back(Student("Taras", 18));
    list.push_back(Student("Lesiia", 28));
    list.push_back(Student("Ivan", 35));

    for( auto it = list.begin(); it != list.end(); it++){
        cout<< it->name << " " << it->age << endl;
    }


    return 0;
}
