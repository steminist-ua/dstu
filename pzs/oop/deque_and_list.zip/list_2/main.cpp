#include <iostream>
#include <list>

using namespace std;

struct Contact
{
    string firstName;
    string lastName;
    string phone;
};

class Contactlist
{
    list<Contact> lists;
public:
    void addContact(Contact contact){
        lists.push_back(contact);
    }
    void removeContact(string _lastName){
        for(auto it = lists.begin(); it!=lists.end(); it++){
            if(it->lastName == _lastName){
                lists.erase(it);
                return;
            }
        }
    }
    void searchContact(string _lastName){
        for(auto it = lists.begin(); it!=lists.end(); it++){
            if(it->lastName == _lastName){
                cout << "name: " <<it->firstName << endl;
                cout << "lastname: " <<it->lastName << endl;
                cout << "phone: " <<it->phone << endl;
            }
        }
    }
};

int main()
{
    Contact c1 = {"Ivan", "Franko", "+380999999999"};
    Contact c2 = {"Lesiia", "Ukrainka", "+380965667788"};

    Contactlist lists;
    lists.addContact(c1);
    lists.addContact(c2);

    lists.searchContact("Franko");
    lists.removeContact("Franko");
    lists.searchContact("Franko");

    return 0;
}
