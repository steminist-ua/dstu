#include <iostream>
#include<deque>

using namespace std;

void convertToBinary(int num){
    deque<int> deq;

    while(num > 0){
        deq.push_front(num%2);
        num = num/2;
    }

    for(auto b : deq){
        cout<<b;
    }
}

int main()
{
    int decimal = 0;
//    cin>>decimal;
    decimal = 62;
    convertToBinary(decimal);
    return 0;
}
